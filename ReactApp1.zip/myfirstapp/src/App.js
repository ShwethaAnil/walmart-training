import React, { Component } from 'react';
//import Library from './Library';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';


class App extends Component{
  constructor(props){
    super(props);

    this.state={
      userInput: "",
      tasklist: []
    }
  }

  updateInput(value){
    this.setState({
      userInput: value
    });
  }

  deleteTask(key){
    const tasklist = [...this.state.tasklist];

    const updateList = tasklist.filter(task=>task.id !== key);

    this.setState({
      tasklist: updateList
    });

  }

  addTask(e){
    if(this.state.userInput !== '' ){
      const userInput = {
        id: Math.random(),
        value: this.state.userInput
      };

      const tasklist = [...this.state.tasklist];
      tasklist.push(userInput);

      this.setState({
        tasklist,
        userInput:""
      });
    }
    e.preventDefault();
  }

  render(){
    return(
      <div className="container">
        <div className="row">
            <div className="rowstyle">
              <p>TASK LIST</p>
            </div>
        </div>
        <hr/>
        <div className="row">
          <div className="col-md-5">
            <form id="form-task">
              <div className="form-group">
                <input type="text" placeholder="Title" value={this.state.userInput} onChange={item=>this.updateInput(item.target.value)} className="form-control" id="title"/>
              </div>
              <button className="btn btn-success" onClick={(e)=>this.addTask(e)}>Add Task</button>
            </form>
          </div>
        </div>
        <div className="row">
          <div className="col-md-5">
            <ul className="list-group">
                 {this.state.tasklist && this.state.tasklist.map((item, index)=>(
                   <li className="list-group-item" key={index}
                   onClick={()=>this.deleteTask(item.id)}>{item.value}</li>
                 ))}
            </ul>
          </div>
        </div>
      </div>
    );
  }

}

export default App;