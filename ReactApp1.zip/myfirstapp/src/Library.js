import React from 'react';

// function Library(){
//     return (<div>Online Library</div>);
// }


const Library = (props) => <div>{props.title}</div>;

export default Library;